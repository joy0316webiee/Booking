import React, { Component } from 'react'

class BookSassion extends Component {
  render() {
    return (
      <div>
        adsfsdf
      </div>
    )
  }
}

export default BookSassion;
