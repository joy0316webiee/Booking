import React, { Component } from 'react'

class Payment extends Component {
  render() {
    return (
      <div>
        adsfsdf
      </div>
    )
  }
}

export default Payment;
